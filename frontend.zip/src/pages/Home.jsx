import Caursel from '../components/Caursel';
import Categories from '../components/Categories';
import BestSeller from '../components/BestSeller';
import Testimonials from '../components/Testimonials';

const Home = () => {
  return (
    <div className="md:mt-28 mt-13">
      <Caursel />

      <div className="py-[100px] flex flex-col space-y-16">  {/* Added space between the components */}
        <Categories />
        <BestSeller />
        <Testimonials />
      </div>

      {/* More content can go here */}
    </div>
  );
};

export default Home;
