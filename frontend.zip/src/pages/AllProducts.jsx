import { useState } from 'react';
import { topCategories } from '../assets/assets';
import { FiFilter } from 'react-icons/fi'; // Filter icon

const AllProducts = () => {
  const [filters, setFilters] = useState({
    sort: '',
    categories: [],
  });

  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Handle sort selection
  const handleSort = (e) => {
    setFilters({ ...filters, sort: e.target.value });
  };

  // Handle category checkbox toggle
  const handleCategoryChange = (category) => {
    let newCategories = [...filters.categories];
    if (newCategories.includes(category)) {
      newCategories = newCategories.filter(cat => cat !== category);
    } else {
      newCategories.push(category);
    }
    setFilters({ ...filters, categories: newCategories });
  };

  // Clear all filters
  const clearFilters = () => {
    setFilters({ sort: '', categories: [] });
  };

  // Apply filtering logic
  let filteredProducts = topCategories;

  if (filters.categories.length > 0) {
    filteredProducts = filteredProducts.filter(item =>
      filters.categories.includes(item.category)
    );
  }

  if (filters.sort === 'low-high') {
    filteredProducts = [...filteredProducts].sort((a, b) => a.price - b.price);
  } else if (filters.sort === 'high-low') {
    filteredProducts = [...filteredProducts].sort((a, b) => b.price - a.price);
  }

  return (
    <div className="flex flex-col md:flex-row max-w-7xl mx-auto p-4 md:py-[180px] py-[120px]">

      {/* Desktop Filter Sidebar */}
      <div className="hidden md:block w-1/4 mb-4 md:mb-0 md:mr-6">
        <div className="bg-white p-4 rounded shadow space-y-4 sticky top-4">
          <h3 className="font-semibold text-lg mb-2">Filters</h3>

          <div>
            <label className="block mb-1 font-medium">Sort By</label>
            <select
              value={filters.sort}
              onChange={handleSort}
              className="w-full border rounded p-2 text-sm"
            >
              <option value="">Select</option>
              <option value="low-high">Price: Low to High</option>
              <option value="high-low">Price: High to Low</option>
              <option value="relevance">Relevance</option>
              <option value="best-seller">Best Seller</option>
            </select>
          </div>

          <div>
            <label className="block mb-1 font-medium">Category</label>
            <div className="space-y-2">
              {['dates', 'nuts', 'berries', 'seeds'].map(category => (
                <div key={category} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id={category}
                    checked={filters.categories.includes(category)}
                    onChange={() => handleCategoryChange(category)}
                    className="form-checkbox h-4 w-4 text-indigo-600"
                  />
                  <label htmlFor={category} className="text-sm capitalize">
                    {category}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={clearFilters}
            className="w-full bg-red-500 text-white py-2 rounded hover:bg-red-600 text-sm"
          >
            Clear Filters
          </button>
        </div>
      </div>

      {/* Product Grid */}
      <div className="w-full md:w-3/4 relative">

        {/* Mobile Filter Icon */}
        <div className="flex justify-end mb-4 md:hidden">
          <button
            onClick={() => setIsFilterOpen(true)}
            className="p-2 border rounded text-sm"
          >
            <FiFilter className="h-6 w-6" />
          </button>
        </div>

        {/* Sliding Mobile Filter Panel */}
        <div className={`fixed top-0 left-0 h-full w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out z-50
          ${isFilterOpen ? 'translate-x-0' : '-translate-x-full'}`}>

          <div className="p-4 flex flex-col h-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-lg">Filters</h3>
              <button onClick={() => setIsFilterOpen(false)} className="text-xl font-bold">
                ✕
              </button>
            </div>

            <div className="mb-4">
              <label className="block mb-1 font-medium">Sort By</label>
              <select
                value={filters.sort}
                onChange={handleSort}
                className="w-full border rounded p-2 text-sm"
              >
                <option value="">Select</option>
                <option value="low-high">Price: Low to High</option>
                <option value="high-low">Price: High to Low</option>
                <option value="relevance">Relevance</option>
                <option value="best-seller">Best Seller</option>
              </select>
            </div>

            <div>
              <label className="block mb-1 font-medium">Category</label>
              <div className="space-y-2">
                {['dates', 'nuts', 'berries', 'seeds'].map(category => (
                  <div key={category} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`mobile-${category}`}
                      checked={filters.categories.includes(category)}
                      onChange={() => handleCategoryChange(category)}
                      className="form-checkbox h-4 w-4 text-indigo-600"
                    />
                    <label htmlFor={`mobile-${category}`} className="text-sm capitalize">
                      {category}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={clearFilters}
              className="mt-4 bg-red-500 text-white py-2 rounded hover:bg-red-600 text-sm"
            >
              Clear Filters
            </button>
          </div>
        </div>

        {/* Overlay when filter is open */}
        {isFilterOpen && (
          <div
            className="fixed inset-0 bg-black opacity-30 z-40"
            onClick={() => setIsFilterOpen(false)}
          />
        )}

        {/* Products Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {filteredProducts.map((item, index) => (
            <div key={index} className="bg-white rounded shadow p-3 flex flex-col items-center">
              <img
                src={item.image}
                alt={item.text}
                className="w-full h-40 object-contain rounded-lg"
              />
              <p className="mt-2 font-medium text-center text-sm">{item.text}</p>
              <p className="text-gray-600 text-sm mt-1">
                ${item.price !== undefined ? item.price.toFixed(2) : "N/A"}
              </p>
              <div className="grid grid-cols-2 gap-2 mt-3 w-full">
                <button className="bg-gray-100 text-gray-600 py-1 text-xs rounded hover:bg-gray-200 transition">
                  Add to Cart
                </button>
                <button className="bg-gray-800 text-white py-1 text-xs rounded hover:bg-gray-900 transition">
                  Buy Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AllProducts;
