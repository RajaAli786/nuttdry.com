import { createContext, useContext, useState } from "react";
import { useNavigate } from "react-router-dom";

//export creating AppContext--------------------------------------------------------------------------------------
export const AppContext = createContext();


//creatign AppContextProvider function -----------------------------------------------------------------------------
export const AppContextProvider = ({children}) =>{

    const navigate = useNavigate();
    const [user, setUser] = useState(null);
    const [admin, setAdmin]= useState(false);

    //decalring value-------
    const value ={navigate, user, setUser, admin, setAdmin}

    return <AppContext.Provider value= {value}>
            {children}
            </AppContext.Provider>
    
}




//export useAppContext function--------------------------------------------------------------------------------
export const useAppContext =()=>{
    return useContext(AppContext)
}