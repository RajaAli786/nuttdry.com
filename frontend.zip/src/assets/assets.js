import berries from './berries.png';
import dates from './dates.png';
import nuts from './nuts.jpeg';
import seeds from './seeds.png';

import banner1 from './banner1.png';
import banner2 from './banner2.jpg';

export const banner = [
  banner1, banner2
];

export const topCategories = [
  {
    text: "Dates",
    path: "dates",
    category: "dates",          
    image: dates,
    bgColor: "#FEF6DA",
    price: 30.00,
  },
  {
    text: "Berries",
    path: "berries",
    category: "berries",        
    image: berries,
    bgColor: "#FEE0E0",
    price: 30.00,
  },
  {
    text: "Nuts",
    path: "nuts",
    category: "nuts",          
    image: nuts,
    bgColor: "#F0F5DE",
    price: 30.00,
  },
  {
    text: "Seeds",
    path: "seeds",
    category: "seeds",          
    image: seeds,
    bgColor: "#E1F5EC",
    price: 30.00,
  },
  {
    text: "Seeds",
    path: "seeds",
    category: "seeds",          
    image: seeds,
    bgColor: "#E1F5EC",
    price: 30.00,
  },
];
