import { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";

const Navbar = () => {
    const navLinks = [
        { name: 'Home', path: '/' },
        {
            name: 'Products', path: '/allproducts', subLinks: [
                { name: 'Dates', path: '/products/dates' },
                { name: 'Nuts', path: '/products/Nuts' },
                { name: 'Dry Fruits', path: '/products/dryfruits' },
                { name: 'Seeds', path: '/products/seeds' },
                { name: 'Berries', path: '/products/berries' },
            ]
        },
        { name: 'Gifitings', path: '/' },
        { name: 'Stores', path: '/' },
        { name: 'About', path: '/' },
        { name: 'Contact us', path: '/Contact' },
    ];

    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [openDropdownIndex, setOpenDropdownIndex] = useState(null);
    const [mobileDropdownIndex, setMobileDropdownIndex] = useState(null);
    const [showOffer, setShowOffer] = useState(true);

    const location = useLocation();

    useEffect(() => {
        setOpenDropdownIndex(null);
        setMobileDropdownIndex(null);
    }, [location]);

    useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 50) {
                setShowOffer(false);
            } else {
                setShowOffer(true);
            }
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const handleMobileDropdownToggle = (index) => {
        setMobileDropdownIndex(prevIndex => (prevIndex === index ? null : index));
    };

    return (
        <div >
            {/* Offers Section */}
            {showOffer && (
                <div className="top-0 left-0 w-full bg-yellow-300 text-center py-2 px-4 md:px-8 text-sm
                 md:text-base font-medium z-50 transition-all duration-300">
                    🎉 Special Offer: Get <span className="font-bold">20% off</span> 
                    on your first order! Use code <span className="font-bold">WELCOME20</span> 🎉
                </div>
            )}

            {/* Main Header */}
            <div className={`fixed left-0 w-full bg-white backdrop-blur-md shadow-md transition-all duration-300 z-40
                 ${showOffer ? 'top-[40px]' : 'top-0'}`}>
                <div className="flex items-center justify-between px-4 md:px-16 lg:px-24 xl:px-32 py-2">
                    <div className="flex items-center gap-4">
                        <svg className="h-6 w-6 text-gray-700 cursor-pointer" fill="none"
                            stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                            <circle cx="11" cy="11" r="8" />
                            <line x1="21" y1="21" x2="16.65" y2="16.65" />
                        </svg>
                        <div className="md:hidden">
                            <button onClick={() => setIsMenuOpen(!isMenuOpen)}>
                                <svg className="h-6 w-6 text-gray-700" fill="none"
                                    stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                    <line x1="4" y1="6" x2="20" y2="6" />
                                    <line x1="4" y1="12" x2="20" y2="12" />
                                    <line x1="4" y1="18" x2="20" y2="18" />
                                </svg>
                            </button>
                        </div>
                    </div>

                    <div className="flex-1 flex justify-center">
                        <NavLink to="/">
                            <img src="https://prebuiltui.com/logo.svg?p=black&s=black&t=black"
                                alt="logo" className="h-8 md:h-10" />
                        </NavLink>
                    </div>

                    <div className="hidden md:flex items-center gap-4">
                        <button className="flex items-center gap-2 border px-4 py-2 rounded-full text-sm font-medium
                         text-gray-700 hover:bg-gray-100 transition">
                            <svg className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                <path d="M3 3h2l.4 2M7 13h10l4-8H5.4" />
                                <circle cx="7" cy="21" r="1" />
                                <circle cx="20" cy="21" r="1" />
                            </svg>
                            Cart
                        </button>
                        <button className="bg-black text-white px-6 py-2 rounded-full text-sm font-medium hover:bg-gray-800 transition">
                            Login
                        </button>
                    </div>
                </div>
            </div>

            {/* Second Navbar */}
            <div className={`fixed left-0 w-full hidden md:block bg-red-200 border-t border-gray-200 transition-all duration-300 z-30
                 ${showOffer ? 'top-[95px]' : 'top-[50px]'}`}>
                <div className="flex justify-center px-4 md:px-8 lg:px-16 xl:px-24 py-4 text-sm md:text-base text-gray-700 overflow-visible">
                    <div className="flex flex-wrap justify-center gap-6 md:gap-12 w-full max-w-7xl">
                        {navLinks.map((link, i) => (
                            <div
                                key={i}
                                className="relative"
                                onMouseEnter={() => setOpenDropdownIndex(i)}
                                onMouseLeave={() => setOpenDropdownIndex(null)}
                            >
                                <NavLink
                                    to={link.path}
                                    className="hover:text-black whitespace-nowrap px-2 py-1"
                                    onClick={() =>
                                        link.subLinks ? setOpenDropdownIndex(i) : setOpenDropdownIndex(null)
                                    }
                                >
                                    {link.name}
                                </NavLink>

                                {link.subLinks && openDropdownIndex === i && (
                                    <div className="absolute left-0 top-full mt-2 w-48 bg-white border border-gray-200 shadow-md rounded-md z-50">
                                        {link.subLinks.map((subLink, index) => (
                                            <NavLink
                                                key={index}
                                                to={subLink.path}
                                                className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                                                onClick={() => setOpenDropdownIndex(null)}
                                            >
                                                {subLink.name}
                                            </NavLink>
                                        ))}
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Mobile Menu */}
            {isMenuOpen && (
                <div className="fixed top-[50px] left-0 w-64 h-full bg-white p-4 space-y-6 z-50 md:hidden">
                    <button className="text-gray-700" onClick={() => setIsMenuOpen(false)}>
                        <svg className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                            <line x1="18" y1="6" x2="6" y2="18" />
                            <line x1="6" y1="6" x2="18" y2="18" />
                        </svg>
                    </button>
                    {navLinks.map((link, i) => (
                        <div key={i}>
                            <div className="flex justify-between items-center">
                                <NavLink
                                    to={link.path}
                                    className="block text-gray-700 hover:text-black py-2"
                                    onClick={() => {
                                        if (!link.subLinks) {
                                            setIsMenuOpen(false);
                                        }
                                    }}
                                >
                                    {link.name}
                                </NavLink>
                                {link.subLinks && (
                                    <button
                                        onClick={() => handleMobileDropdownToggle(i)}
                                        className="p-2 hover:bg-gray-200 rounded"
                                    >
                                        <svg
                                            className={`h-4 w-4 transform transition-transform ${mobileDropdownIndex === i ? 'rotate-180' : ''}`}
                                            fill="none"
                                            stroke="currentColor"
                                            strokeWidth="2"
                                            viewBox="0 0 24 24"
                                        >
                                            <path d="M19 9l-7 7-7-7" />
                                        </svg>
                                    </button>
                                )}
                            </div>
                            {link.subLinks && mobileDropdownIndex === i && (
                                <div className="pl-4 mt-2 space-y-1">
                                    {link.subLinks.map((subLink, index) => (
                                        <NavLink
                                            key={index}
                                            to={subLink.path}
                                            className="block text-gray-600 hover:text-gray-800 py-1"
                                            onClick={() => setIsMenuOpen(false)}
                                        >
                                            {subLink.name}
                                        </NavLink>
                                    ))}
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default Navbar;
