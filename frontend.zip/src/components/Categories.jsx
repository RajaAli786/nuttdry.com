import React, { useRef } from 'react';
import { topCategories } from '../assets/assets';

const Categories = () => {
  const carouselRef = useRef(null);

const scroll = (direction) => {
  if (carouselRef.current) {
    const container = carouselRef.current;
    console.log("Scroll triggered", direction);
    console.log("ScrollWidth:", container.scrollWidth, "ClientWidth:", container.clientWidth);
    const scrollAmount = container.offsetWidth / (window.innerWidth >= 768 ? 3 : 2);
    container.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth'
    });
  }
};


  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header with navigation */}
    <div className="flex items-center justify-center mb-4 space-x-4">
  <button
    onClick={() => scroll('left')}
    className="p-2 bg-gray-200 rounded hover:bg-gray-300"
  >
    ❮
  </button>

  <h2 className="text-xl font-semibold text-center">
    Our Categories
  </h2>

  <button
    onClick={() => scroll('right')}
    className="p-2 bg-gray-200 rounded hover:bg-gray-300"
  >
    ❯
  </button>
</div>


      {/* View All centered */}
      <div className="text-center mb-4">
        <a href="#" className="text-blue-600 hover:underline text-sm">
          View All
        </a>
      </div>

      {/* Carousel Wrapper */}
      <div className="overflow-x-auto hide-scrollbar">
       <div
  ref={carouselRef}
  className="flex gap-4 overflow-x-auto transition-transform duration-300 ease-in-out hide-scrollbar"
>
          {topCategories.map((item, index) => (
            <div
              key={index}
              className="flex-shrink-0 w-1/2 md:w-1/3"
            >
              <div className="bg-white rounded-lg shadow-md p-2  " style={{ backgroundColor: item.bgColor }}>
                <img
                  src={item.image}
                  alt={item.text}
                  className="w-fit h-full object-contain rounded-md"
                />
                <p className="text-center mt-2 text-sm font-medium">{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Categories;
