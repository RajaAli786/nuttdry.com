import React, { useRef } from 'react';
import { topCategories } from '../assets/assets';

const BestSeller = () => {
  const carouselRef = useRef(null);

  const scroll = (direction) => {
    if (carouselRef.current) {
      const container = carouselRef.current;
      const scrollAmount = container.offsetWidth / (window.innerWidth >= 768 ? 4 : 2);
      container.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Header with navigation */}
      <div className="flex items-center justify-center mb-2 space-x-4">
        <button
          onClick={() => scroll('left')}
          className="p-2 bg-gray-200 rounded hover:bg-gray-300"
        >
          ❮
        </button>

        <h2 className="text-xl font-semibold text-center">
          BestSeller
        </h2>

        <button
          onClick={() => scroll('right')}
          className="p-2 bg-gray-200 rounded hover:bg-gray-300"
        >
          ❯
        </button>
      </div>

      {/* View All link */}
      <div className="text-center mb-4">
        <a href="#" className="text-blue-600 hover:underline text-sm">
          View All
        </a>
      </div>

      {/* Carousel Wrapper */}
      <div className="overflow-x-auto hide-scrollbar">
        <div
          ref={carouselRef}
          className="flex gap-3 overflow-x-auto transition-transform duration-300 ease-in-out hide-scrollbar"
        >
          {topCategories.map((item, index) => (
            <div key={index} className="flex-shrink-0 w-1/2 md:w-1/4">
              <div className="bg-white rounded-lg shadow-md p-3 h-full flex flex-col items-center">
                <img
                  src={item.image}
                  alt={item.text}
                  className="w-full h-48 object-contain rounded-[40px]"
                />
                <p className="text-center mt-2 text-sm font-medium">{item.text}</p>
                <p className="text-center text-gray-600 mt-1">$ 29.00</p>
                <div className="grid grid-cols-2 gap-2 mt-3 w-full">
                  <button className="bg-gray-100 text-gray-600 py-1 text-xs rounded hover:bg-gray-200 transition">
                    Add to Cart
                  </button>
                  <button className="bg-gray-800 text-white py-1 text-xs rounded hover:bg-gray-900 transition">
                    Buy Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BestSeller;
