import {  Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Contact from './pages/Contact'
import AllProducts from './pages/AllProducts'

const App = () => {
  return (
    <div  className='text-default min-h-screen text-gray-700 bg-white'>
      <Navbar/>
      <Routes>
        <Route path='/' element= {<Home/>}/>
        <Route path='/contact' element= {<Contact/>}/>
        <Route path='/allproducts' element= {<AllProducts/>}/>
      </Routes>
      <Footer/>
    </div>

  )
}

export default App